import json
import boto3
import os

polly = boto3.client('polly')
s3 = boto3.client('s3')
bucket_name = os.environ['S3_BUCKET']

def lambda_handler(event, context):
    # Log the incoming event for debugging
    print("Incoming event:", json.dumps(event))

    # ✅ Handle both API Gateway and direct Lambda invocation
    try:
        if "body" in event and isinstance(event["body"], str):
            body = json.loads(event["body"])  # API Gateway format
        else:
            body = event  # Direct invocation
    except Exception as e:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": f"Invalid input format: {str(e)}"})
        }

    # Validate input
    text = body.get("text")
    if not text:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing 'text' field in request"})
        }

    try:
        # Generate speech using Amazon Polly
        polly_response = polly.synthesize_speech(
            Text=text,
            OutputFormat="mp3",
            VoiceId="Joanna"
        )

        # Create a unique file name
        file_name = f"{text[:10].replace(' ', '_')}.mp3"

        # Upload the generated audio to S3
        s3.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=polly_response["AudioStream"].read()
        )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Audio generated successfully",
                "s3_url": f"https://{bucket_name}.s3.amazonaws.com/{file_name}"
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
